package com.example.jarvisai

import android.app.Activity
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private val REQ = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 18)
            setBackgroundColor(Color.rgb(5,7,10))
        }

        val title = TextView(this).apply {
            text = "JARVIS AI"
            textSize = 26f
            setTextColor(Color.rgb(0,220,240))
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 22)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        chat = TextView(this).apply {
            text = "வணக்கம்! நான் Jarvis AI.\nஉங்களுக்கு எப்படி உதவலாம்?"
            textSize = 19f
            setTextColor(Color.WHITE)
            setPadding(20,20,20,20)
        }
        val scroll = ScrollView(this)
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        input = EditText(this).apply {
            hint = "இங்கே type செய்யுங்கள்..."
            hintTextColor = Color.GRAY
            setTextColor(Color.WHITE)
            setSingleLine(true)
        }
        root.addView(input, LinearLayout.LayoutParams(-1,-2))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val voice = Button(this).apply {
            text = "🎙️ Voice"
            setOnClickListener { startVoice() }
        }
        val send = Button(this).apply {
            text = "Send"
            setOnClickListener { reply(input.text.toString()) }
        }
        row.addView(voice, LinearLayout.LayoutParams(0,-2,1f))
        row.addView(send, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(row)

        setContentView(root)
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        startActivityForResult(i, REQ)
    }

    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode == REQ && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            input.setText(text)
            reply(text)
        }
    }

    private fun reply(text:String) {
        if (text.isBlank()) return
        val answer = "நீங்கள் சொன்னது: $text\n\nJarvis: உங்கள் AI assistant தயாராக இருக்கிறது. AI API இணைத்தால் உண்மையான AI பதில்களையும் வழங்க முடியும்."
        chat.text = answer
        tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        input.text.clear()
    }

    override fun onInit(status:Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("ta","IN")
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}