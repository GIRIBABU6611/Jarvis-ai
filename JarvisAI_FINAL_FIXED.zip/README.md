# Jarvis AI Android App

Tamil-first Jarvis-style Android starter app with:
- Tamil voice input
- Tamil text-to-speech voice reply
- Dark Jarvis UI
- Local demo response

## Build APK
Open this folder in Android Studio, allow Gradle sync, then:
Build > Build APK(s)

The generated debug APK will be under:
app/build/outputs/apk/debug/app-debug.apk

For real AI answers, connect an AI API/backend and keep API keys out of the APK.